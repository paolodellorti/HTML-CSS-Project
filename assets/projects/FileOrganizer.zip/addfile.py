import os, shutil, csv, argparse, sys

#la funzione aggiorna il file csv, e in caso servisse, lo crea
def write_csv(name, typ, size):
    if 'recap.csv' not in os.listdir():
        with open('recap.csv', 'w', newline='') as recap:
            writer = csv.writer(recap)        
            writer.writerow(['name', 'type', 'size(B)'])
    with open('recap.csv', 'a', newline='') as recap:
        writer = csv.writer(recap)        
        writer.writerow([name, typ, size])

#creo la funzione che mi permette di spostare i file nella cartella assegnata, poi stampo le informazioni e aggiorno il recap
#uso il try/except nel caso in cui esistesse già un file uguale nella cartella di destinazione.
def move_write(file, typ, path):
        try:    
            name = os.path.splitext(file)[0]
            size = os.stat(file).st_size
            shutil.move(file, os.path.join(os.getcwd(), path))
            write_csv(name, typ, size)
            print('{} type: {} size: {}B'.format(name, typ, size))
            print('Ho eseguito il programma {} sul file {}'.format(sys.argv[0], sys.argv[1]))

        except:
            print('Impossibile spostare il file {}. Esiste già nella cartella di destinazione.'.format(file))

#creo la funzione principale che mi permette di verificare l'estensione del file. ho messo le estensioni più conosciute. inoltre, nel caso non esistessero già, creo le sottocartelle di files.
#nel caso in cui il file fosse di un'estensione sconosciuta oppure non esistesse, stampo un messaggio di errore.
def main_func(nome_file):
    if nome_file not in os.listdir():
        print('Il file scelto non è presente nella cartella files.')
        
    elif nome_file.endswith('.jpeg') or nome_file.endswith('.jpg') or nome_file.endswith('.png') or nome_file.endswith('.gif'):
        if not os.path.exists('images'):
            os.makedirs('images')
        move_write(nome_file, 'image', 'images')

    elif nome_file.endswith('.txt') or nome_file.endswith('.odt') or nome_file.endswith('.doc') or nome_file.endswith('.docx'):
        if not os.path.exists('docs'):
            os.makedirs('docs')
        move_write(nome_file, 'text', 'docs')

    elif nome_file.endswith('.mp3') or nome_file.endswith('.wav') or nome_file.endswith('.wma') or nome_file.endswith('.flac'):
        if not os.path.exists('audio'):
            os.makedirs('audio')
        move_write(nome_file, 'audio', 'audio')
    
    else:
        print('Il file che stai cercando di spostare ha una estensione che non conosco.')

#ho pensato che questo file originariamente si trovi nella cartella principale FileOrganizer, 
#quindi con questa parte dello script mi sposto nella cartella file dalle due possibili cartelle in cui mi potrei trovare
# mi sembra un po' macchinoso ma non ho trovato alternative, ho cercato di utilizzare un codice universale che vada bene su qualsiasi computer
if os.getcwd().endswith('images'):
    os.chdir('..')
elif os.getcwd().endswith('FileOrganizer'):
    os.chdir('./files')

#creo la possibilità per l'utente di andare a spostare un singolo file scrivendo il nome completo del file
parser = argparse.ArgumentParser(description="Semplice programma per spostare singoli files")

parser.add_argument("nome_file", type=str, help="Nome del file da spostare")

args = parser.parse_args()

ris = main_func(args.nome_file)


